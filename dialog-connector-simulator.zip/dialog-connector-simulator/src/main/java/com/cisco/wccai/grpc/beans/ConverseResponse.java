package com.cisco.wccai.grpc.beans;

import io.strati.libs.commons.lang3.builder.ToStringBuilder;
import io.strati.libs.jackson.annotation.JsonInclude;
import io.strati.libs.jackson.annotation.JsonProperty;
import io.strati.libs.jackson.annotation.JsonPropertyOrder;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "status",
        "contextOutput",
        "shortText",
        "response"
})
public class ConverseResponse {
	@JsonProperty("status")
	private String status;
	@JsonProperty("contextOutput")
	private ContextOutput contextOutput = new ContextOutput();
	@JsonProperty("shortText")
	private String shortText;
	@JsonProperty("response")
	private String response;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@JsonProperty("contextOutput")
	public ContextOutput getContextOutput() {
		return contextOutput;
	}

	@JsonProperty("contextOutput")
	public void setContextOutput(ContextOutput contextOutput) {
		this.contextOutput = contextOutput;
	}

	@JsonProperty("shortText")
	public String getShortText() {
		return shortText;
	}

	@JsonProperty("shortText")
	public void setShortText(String shortText) {
		this.shortText = shortText;
	}

	@JsonProperty("response")
	public String getResponse() {
		return response;
	}

	@JsonProperty("response")
	public void setResponse(String response) {
		this.response = response;
	}

	@Override
	public String toString() {
		return "HandlerResponse{" +
				"status='" + status + '\'' +
				", contextOutput=" + contextOutput +
				", shortText='" + shortText + '\'' +
				", response='" + response + '\'' +
				'}';
	}

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonPropertyOrder({
			"responseDataMap"
	})
	public static class ContextOutput {

		@JsonProperty("responseDataMap")
		private Map<String, List<String>> responseDataMap = new HashMap<>();

		@JsonProperty("responseDataMap")
		public Map<String, List<String>> getResponseDataMap() {
			return responseDataMap;
		}

		@JsonProperty("responseDataMap")
		public void setResponseDataMap(Map<String, List<String>> responseDataMap) {
			this.responseDataMap = responseDataMap;
		}

		public void addResponseData(final String key, final List<String> value) {
			responseDataMap.put(key, value);
		}

		@Override
		public String toString() {
			return new ToStringBuilder(this).append("responseDataMap", responseDataMap).toString();
		}
	}

}
