package com.cisco.wccai.grpc.service;

import java.io.File;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

import com.cisco.wccai.grpc.server.GrpcServer;
import com.google.auth.Credentials;
import com.google.cloud.ReadChannel;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import com.google.common.io.ByteStreams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public enum BlockStorageServiceImpl implements BlockStorageService {
	INSTANCE;

    private static final Logger LOGGER = LoggerFactory.getLogger(GrpcServer.class);

//    public static void main(String... args) throws Exception {
//        write("spch-2-text", "/Users/t0h0efk/project/TextSpeechUtility/src/test/resources/testtest.wav",
//                "audioFile");
//        read("spch-2-text", "audioFile", "outputFile.wav");
//    }

    public void write(String bucketName, String filePath, String objectName) throws Exception {

        LOGGER.info("writing bucketName: {}, filePath: {}, objectName: {}", bucketName, filePath, objectName);
           
        StorageOptions defaultInstance = StorageOptions.getDefaultInstance();
      
      
		Storage storage = defaultInstance.getService();

        BlobId blobId = BlobId.of(bucketName, objectName);
        BlobInfo blobInfo = BlobInfo.newBuilder(blobId).build();

        storage.create(blobInfo, Files.readAllBytes(Paths.get(filePath)));
        LOGGER.info("written bucketName: {}, filePath: {}, objectName: {}", bucketName, filePath, objectName);
    }

    public void read(String bucketName, String objectName, String outputFileFullPath) throws Exception {
    	 StorageOptions defaultInstance = StorageOptions.getDefaultInstance();
    	 Credentials credentials = defaultInstance.getCredentials();
         LOGGER.info("credentials AuthenticationType {}", credentials.getAuthenticationType());
         LOGGER.info("credentials getRequestMetadata {}", credentials.getRequestMetadata());
        Storage storage = defaultInstance.getService();
        File file = new File(outputFileFullPath);
        if (!file.exists()) {
            file.createNewFile();
        }
        try (ReadChannel reader = storage.reader(BlobId.of(bucketName, objectName));

             FileChannel targetFileChannel = FileChannel.open(Paths.get(outputFileFullPath),
                     StandardOpenOption.WRITE)) {

            ByteStreams.copy(reader, targetFileChannel);

            System.out.println("Downloaded object " + objectName + " from bucket " + bucketName + " to "
                    + outputFileFullPath + " using a ReadChannel.");
        }
    }
}