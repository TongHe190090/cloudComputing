package com.cisco.wccai.grpc.server;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cisco.wcc.ccai.v1.Virtualagent.Dtmf;
import com.cisco.wccai.grpc.server.VAResponse.Item;
import com.google.cloud.speech.v1.StreamingRecognizeRequest;

public class AsyncDTMFTaskExecutionWorker implements Runnable{
	private static final Logger LOGGER = LoggerFactory.getLogger(AsyncDTMFTaskExecutionWorker.class);
	private  ArrayBlockingQueue<Dtmf> dtmfSymbols;
	private ArrayBlockingQueue<String> replyQueue;
	private String conversationId;
	private volatile boolean finished;
	private volatile StringBuffer currentWholeInfo = new StringBuffer();
	
	private static  Map<Dtmf, String> mapping = new HashMap<>();
	static {
		mapping.put(Dtmf.DTMF_A, "A");
		mapping.put(Dtmf.DTMF_B, "B");
		mapping.put(Dtmf.DTMF_C, "C");
		mapping.put(Dtmf.DTMF_D, "D");
		mapping.put(Dtmf.DTMF_ONE, "1");
		mapping.put(Dtmf.DTMF_TWO, "2");
		mapping.put(Dtmf.DTMF_THREE, "3");
		mapping.put(Dtmf.DTMF_FOUR, "4");
		mapping.put(Dtmf.DTMF_FIVE, "5");
		mapping.put(Dtmf.DTMF_SIX, "6");
		mapping.put(Dtmf.DTMF_SEVEN, "7");
		mapping.put(Dtmf.DTMF_EIGHT, "8");
		mapping.put(Dtmf.DTMF_NINE, "9");
		mapping.put(Dtmf.DTMF_POUND, "#");
		mapping.put(Dtmf.DTMF_STAR, "*");
		mapping.put(Dtmf.DTMF_ZERO, "0");
		
	}
	

	public AsyncDTMFTaskExecutionWorker(ArrayBlockingQueue<Dtmf> dtmfSymbols, ArrayBlockingQueue<String> replyQueue,
			String conversationId) {
		this.dtmfSymbols = dtmfSymbols;
		this.replyQueue = replyQueue;
		this.conversationId = conversationId;
	}
	
	public void setFinished() {
		finished = true;
	}

	@Override
	public void run() {
		 while (!finished) {
			 
			try {
				Dtmf item = dtmfSymbols.take();
				LOGGER.info("take item {}", item);
				String info = transform(item);
				LOGGER.info("current info {}", info);
				
				if("*".equals(info) || "#".equals(info)) {
					String dtmfWholeInfo = currentWholeInfo.toString();
					LOGGER.info("the current DTMF whole info  {}", dtmfWholeInfo);
					this.replyQueue.add(dtmfWholeInfo);
					currentWholeInfo.setLength(0);
				}else {
					currentWholeInfo.append(info);
				}
			} catch (InterruptedException e) {
				LOGGER.error(e.getMessage(), e);
				
			}
			    
			    
			    
		 }
			    
		
	}

	private String transform(Dtmf item) {
		String result = mapping.get(item);
		if(result == null) {
			LOGGER.info("unrecognized dtmf {}", item );
			return "";
		}
		return result;
	}
	

}
