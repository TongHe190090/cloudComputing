package com.cisco.wccai.grpc.server;

import com.cisco.wcc.ccai.v1.CcaiApi;
import com.cisco.wcc.ccai.v1.CcaiApi.StreamingAnalyzeContentResponse;
import com.cisco.wcc.ccai.v1.Recognize;
import com.cisco.wcc.ccai.v1.Virtualagent;
import com.cisco.wccai.grpc.beans.ConverseResponse;
import com.cisco.wccai.grpc.converter.AudioToTextConverter;
import com.cisco.wccai.grpc.converter.TextToAudioConverter;
import com.cisco.wccai.grpc.integ.ConverseConnector;
import com.cisco.wccai.grpc.model.Response;
import com.cisco.wccai.grpc.model.State;
import com.cisco.wccai.grpc.server.ConversationStateManager.ConversationDTMFState;
import com.cisco.wccai.grpc.server.ConversationStateManager.ConversationState;
import com.cisco.wccai.grpc.server.VAResponse.Item;
import com.cisco.wccai.grpc.service.BlockStorageServiceImpl;
import com.cisco.wccai.grpc.utils.LoadProperties;
import com.cisco.wccai.grpc.utils.Utils;
import com.google.protobuf.ByteString;
import io.grpc.stub.StreamObserver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import java.io.*;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;




public class VAResponse {

	
	private static final Logger LOGGER = LoggerFactory.getLogger(VAResponse.class);
	public static final String CALL_START = "CALL_START";
	public static final String CALL_END = "CALL_END";
	private boolean isFirstTimeDTMF = Boolean.TRUE;
	private boolean isTermCharacter = Boolean.TRUE;

	private static final Properties properties = LoadProperties.loadProperties();
	private static final int PROMPT_DURATION_SEC = Integer.parseInt(properties.getProperty("PROMPT_DURATION_MS"));
	private final long startTime = System.currentTimeMillis();
	private boolean isStartOfInput = false;
	private boolean isEndOfInput = false;
	private boolean isDtmfReceived = false;
	
    static class Item{
    	ByteString byteString;
		Item(ByteString byteString){
			this.byteString = byteString;
		}
	}
    

	VAResponse() {

	}

	public void buildVAResponse(CcaiApi.StreamingAnalyzeContentRequest request,
			StreamObserver<CcaiApi.StreamingAnalyzeContentResponse> responseObserver) {
		LOGGER.info("VAResponse instance {} ", this.toString());
		Virtualagent.VirtualAgentResult result;
		if (request.hasEvent()) {
			switch (request.getEvent().getEventType().toString()) {
			case CALL_START:
				LOGGER.info("received CALL_START event for conversationId : {} ", request.getConversationId());
				break;
			case CALL_END:
				LOGGER.info("CALL_END buildVAResponse currentThread {}"+Thread.currentThread());
				LOGGER.info("received CALL_END event for conversationId : {} ", request.getConversationId());
				responseObserver.onNext(Context.getResponse(State.CALL_END).getCallEndResponse());
				ConversationStateManager.getConversationState(request.getConversationId(), null).tasks.add(new Item(null));
				ConversationStateManager.releaseAllResource(request.getConversationId());
				break;
			default:
				result = Virtualagent.VirtualAgentResult.newBuilder().setResponsePayload("UNSPECIFIED EVENT RECEIVED")
						.build();
				responseObserver
						.onNext(CcaiApi.StreamingAnalyzeContentResponse.newBuilder().setVaResult(result).build());
				break;

			}
		} else if (request.hasDtmf()) {
			LOGGER.info("received dtmf event for conversationId : {} ", request.getConversationId());
			processDTMF(request, responseObserver);
		} else {
			LOGGER.info("received audio from client for conversationId : {} ", request.getConversationId());
			processAudio(responseObserver, request);
		}
	}

	public boolean isDtmfReceived() {
		return isDtmfReceived;
	}

	private void processDTMF(CcaiApi.StreamingAnalyzeContentRequest request,
			StreamObserver<CcaiApi.StreamingAnalyzeContentResponse> responseObserver) {

		Virtualagent.Dtmf dtmf = request.getDtmf().getDtmfEventsList().get(0);
		LOGGER.info("Dtmf input {}", dtmf);
		
		ConversationDTMFState  taskAndReplyQueue = ConversationStateManager.getConversationStateForDTMF(request.getConversationId(), dtmf);
		if (isFirstTimeDTMF) {
			isDtmfReceived = true;
			isFirstTimeDTMF = false;
			LOGGER.info("received first character for conversationId : {} , sending START_OF_INPUT event ",
					request.getConversationId());
			responseObserver.onNext(Context.getResponse(State.START_OF_INPUT).getStartOfInputResponse());
		} else  {
			if(!taskAndReplyQueue.replyQueue.isEmpty()) {
			    LOGGER.info("writing END_OF_INPUT event to VB client for conversationId : {}",request.getConversationId());
	            responseObserver.onNext(Context.getResponse(State.END_OF_INPUT).getEndOfInputResponse());
	            this.isEndOfInput = true;
			}else{
				LOGGER.info("writing PARTIAL_RECOGNITION event to VB client for conversationId : {}", request.getConversationId());
				responseObserver.onNext(Context.getResponse(State.PARTIAL_RECOGNITION).getPartialRecognitionResponse());
				
			}
		}
	}


	// Refer readme for detail flow. (Virtual Agent mode section)
	private void processAudio(StreamObserver<CcaiApi.StreamingAnalyzeContentResponse> responseObserver,
			CcaiApi.StreamingAnalyzeContentRequest request) {
		LOGGER.info("processAudio this current time {}", SimpleDateFormat.getDateTimeInstance().format(new Date()));

		if (!isStartOfInput) {
			isStartOfInput = true;
			LOGGER.info("writing EVENT_START_OF_INPUT event to VB client for conversationId : {}",request.getConversationId());
					
			LOGGER.info("writing EVENT_START_OF_INPUT  response conversationId : {}",
					Context.getResponse(State.START_OF_INPUT).getStartOfInputResponse());
			responseObserver.onNext(Context.getResponse(State.START_OF_INPUT).getStartOfInputResponse());
		}else {
			ConversationState  taskAndReplyQueue = ConversationStateManager.getConversationState(request.getConversationId(), request.getAudio());
			ConversationDTMFState  taskAndReplyDTMFQueue = ConversationStateManager.getConversationStateForDTMF(request.getConversationId(), null);
			if(!taskAndReplyQueue.replyQueue.isEmpty() || !taskAndReplyDTMFQueue.replyQueue.isEmpty()) {
			    LOGGER.info("writing END_OF_INPUT event to VB client for conversationId : {}",request.getConversationId());
	            responseObserver.onNext(Context.getResponse(State.END_OF_INPUT).getEndOfInputResponse());
	            this.isEndOfInput = true;
			}else{
				LOGGER.info("writing PARTIAL_RECOGNITION event to VB client for conversationId : {}", request.getConversationId());
				responseObserver.onNext(Context.getResponse(State.PARTIAL_RECOGNITION).getPartialRecognitionResponse());
				
			}
			
		}

	}


	public boolean setEndOfInputToFalse() {
		return isEndOfInput =  false;
	}


	public boolean isEndOfInput() {
		return isEndOfInput;
	}

}
