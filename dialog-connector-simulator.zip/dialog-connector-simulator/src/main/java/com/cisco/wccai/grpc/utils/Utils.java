package com.cisco.wccai.grpc.utils;
import com.cisco.wccai.grpc.server.GrpcServer;
import com.walmart.platform.scm.client.shared.framework.rest.DefaultClientConfig;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class Utils {

    private static final Logger LOGGER = LoggerFactory.getLogger(GrpcServer.class);
    private static final Properties PROPERTY = LoadProperties.loadProperties();
    private static final String AUDIO_ENCODING_TYPE = PROPERTY.getProperty("AUDIO_ENCODING_TYPE");
    private static final int BUFFER_SIZE = Integer.parseInt(PROPERTY.getProperty("BUFFER_SIZE"));
    private static final String LINEAR_16 = "LINEAR_16";
    private DefaultClientConfig restConfig = new DefaultClientConfig();

    Utils()
    {

    }
    public static InputStream getAudioBytes() {
//        byte[] audioBytes;
//        if (LINEAR_16.equalsIgnoreCase(AUDIO_ENCODING_TYPE)) {
//            audioBytes = new byte[16 * BUFFER_SIZE];
//        } else {
//            audioBytes = new byte[BUFFER_SIZE];
//        }
//        Arrays.fill(audioBytes, (byte) 1);
        
       
      //  try {
			return  getInputStreamForBookAFlight();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
       // return null;
    }

    public static InputStream getInputStream(String fileName) {
        return Utils.class.getClassLoader().getResourceAsStream("audio/check_order/pcm_mulaw/" + fileName);
    }

    public static InputStream getInputStreamForWelcome() {
        return Utils.class.getClassLoader().getResourceAsStream("audio/check_order/pcm_mulaw/welcomeprompt.wav");
    }

    public static InputStream getInputStreamForBookAFlight() {
        return Utils.class.getClassLoader().getResourceAsStream("audio/converseResponse.wav");
    }

    public static InputStream getInputStreamForThankYouForYourHelp() {
        return Utils.class.getClassLoader().getResourceAsStream("audio/check_order/pcm_mulaw/6_thank_you_for_your_help.wav");
    }

    public static InputStream getInputStreamForOutput() {
        return Utils.class.getClassLoader().getResourceAsStream("audio/check_order/pcm_mulaw/output_1.wav");
    }

    public static InputStream getInputStreamForServerResponse() {
        return Utils.class.getClassLoader().getResourceAsStream("audio/server_response.wav");
    }

    public static InputStream getInputStreamForAppDefaultCredentials() {
        LOGGER.info("Reading the file: audio/application_default_credentials.json");
        return Utils.class.getClassLoader().getResourceAsStream("audio/application_default_credentials.json");
    }
    


    public static byte[] readAudioBytes(String fileName) throws IOException {
        InputStream is = Utils.class.getClassLoader().getResourceAsStream("audio/check_order/pcm_mulaw/" + fileName);
        byte[] bytes = is.readAllBytes();
        return bytes;
    }

}
