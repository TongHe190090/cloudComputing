package com.cisco.wccai.grpc.service;

import java.util.List;

import com.google.cloud.bigtable.data.v2.models.Row;
import com.google.cloud.bigtable.data.v2.models.RowCell;

public interface BigTableOperationService {

	void close();

	void createTable(String columnFamily);

	void writeToTable(String columnFamily, String rowKey, String columnQualifier, String value);

	void writeToTable(String columnFamily, String rowKey, List<String[]> list);

	Row readSingleRow(String rowKey);

	List<RowCell> readSpecificCells(String rowKey, String columnFamily, String columnQualifier);

	List<Row> readTable();

	void deleteTable();

}