package com.cisco.wccai.grpc.converter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import com.google.cloud.texttospeech.v1.AudioConfig;
import com.google.cloud.texttospeech.v1.AudioEncoding;
import com.google.cloud.texttospeech.v1.SsmlVoiceGender;
import com.google.cloud.texttospeech.v1.SynthesisInput;
import com.google.cloud.texttospeech.v1.SynthesizeSpeechResponse;
import com.google.cloud.texttospeech.v1.TextToSpeechClient;
import com.google.cloud.texttospeech.v1.VoiceSelectionParams;
import com.google.protobuf.ByteString;

public class TextToAudioConverter {
//    INSTANCE;

    public static void synthesizeText(String text, OutputStream outputStream) {
        try (TextToSpeechClient textToSpeechClient = TextToSpeechClient.create()) {
            // Set the text input to be synthesized
            SynthesisInput input = SynthesisInput.newBuilder().setText(text).build();

            // Build the voice request
            VoiceSelectionParams voice = VoiceSelectionParams.newBuilder().setLanguageCode("en-US")
                    .setSsmlGender(SsmlVoiceGender.FEMALE).build();

            // Select the type of audio file you want returned
            AudioConfig audioConfig = AudioConfig.newBuilder().setSampleRateHertz(8000)
                    .setAudioEncoding(AudioEncoding.MULAW)
                    .build();

            // Perform the text-to-speech request
            SynthesizeSpeechResponse response = textToSpeechClient.synthesizeSpeech(input, voice, audioConfig);

            // Get the audio contents from the response
            ByteString audioContents = response.getAudioContent();

            // Write the response to the output file.
            outputStream.write(audioContents.toByteArray());
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage(), e);
        }

    }

    public void synthesizeText(String text, String outputFileFullPath) {
        File outputFile = new File(outputFileFullPath);
        if (!outputFile.exists())
            try {
                outputFile.createNewFile();
            } catch (IOException e1) {
                throw new RuntimeException(e1.getMessage(), e1);
            }
        try (OutputStream out = new FileOutputStream(outputFile)) {
            synthesizeText(text, out);

        } catch (IOException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

}