package com.cisco.wccai.grpc.config;

public class Config {
    Config(){

    }

    public static final String ORG_ID="35ab2a07-515b-4881-911e-c6916d2ff511";
    public static final String CONFIG_ID="2bc6f93a-0edf-4a5c-9122-7d689be3fff7";
    public static final int NO_OF_VOICE_REQUEST_PER_CALL = 2;
    public static final int NO_OF_DTMF_REQUEST_PER_CALL = 1;
}

