package com.cisco.wccai.grpc.service;

import com.google.gson.Gson;

public class AgentEscalationService {
	private final String endPoint;
	
	AgentEscalationService( String endPoint){
		this.endPoint = endPoint;
	}
	
	private static class AgentEscalationInfo{
		private String intent;
		private String action;
		private String destination;
		private String transferNumber;
		private String transferName;
		private String storeID;
		private String ani;
		private String dnis;
		private String walmartContactID;
		public AgentEscalationInfo(String intent, String action, String destination, String transferNumber,
				String transferName, String storeID, String ani, String dnis, String walmartContactID) {
			super();
			this.intent = intent;
			this.action = action;
			this.destination = destination;
			this.transferNumber = transferNumber;
			this.transferName = transferName;
			this.storeID = storeID;
			this.ani = ani;
			this.dnis = dnis;
			this.walmartContactID = walmartContactID;
		}
		
		
		
		
	}
	
	public void sendAgentEscalation(String intent,
	 String action,
	 String destination,
	 String transferNumber,
	 String transferName,
	 String storeID,
	 String ani,
	 String dnis,
	 String walmartContactID) {
		Gson gson = new Gson();
		
		
		AgentEscalationInfo agentEscalationInfo =new  AgentEscalationInfo( intent,  action,  destination,  transferNumber,
				 transferName,  storeID,  ani,  dnis,  walmartContactID );
		String json = gson.toJson(agentEscalationInfo);
		// send json to the endpoint
				 
			
		
	}

}
