package com.cisco.wccai.grpc.integ;

import com.cisco.wccai.grpc.beans.ConverseRequest;
import com.cisco.wccai.grpc.beans.ConverseResponse;
import com.cisco.wccai.grpc.server.StreamingAnalyzeContentObserver;
import com.cisco.wccai.grpc.utils.LoadProperties;
import com.walmart.platform.scm.client.shared.framework.rest.DefaultClientConfig;
import com.walmart.platform.scm.client.shared.framework.rest.RestClient;
import com.walmart.platform.scm.client.shared.framework.rest.RestClientException;
import com.walmart.platform.scm.client.shared.framework.rest.RestResponse;
import io.strati.libs.google.gson.reflect.TypeToken;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class ConverseConnector {
	private static final Logger LOGGER = LoggerFactory.getLogger(ConverseConnector.class);
	public static final String TRANSFER_AGENT_TEXT = "wait while I transfer your call to an agent";
    public static String sendRequestToConverse(String utterance) {
        DefaultClientConfig restConfig = addDefaultConfig();
        ConverseRequest request = buildConverseRequest(utterance);
        final String WALLY_GA_STORE_IVR_CUSTOMER_STAGING = LoadProperties.loadProperties().getProperty("WALLY_GA_STORE_IVR_CUSTOMER_STAGING");
        String responseText = "";

        try {
            RestClient client = new RestClient(restConfig);
            long start = System.currentTimeMillis();

            System.out.println("Converse staging endpoint: " + WALLY_GA_STORE_IVR_CUSTOMER_STAGING + ", with request: " + request);
            RestResponse restResponse = client.post(WALLY_GA_STORE_IVR_CUSTOMER_STAGING, request);
            
            int responseCode = restResponse.getResponseCode();
            if (responseCode == 200) {
            	LOGGER.info("converse response string {}", restResponse.getResponseString());
            	if (restResponse.getResponseString().toString().contains(TRANSFER_AGENT_TEXT)) {
            		return TRANSFER_AGENT_TEXT;
            	}
                String[] responseArr = restResponse.getResponseString().split("text");
                
                responseText = responseArr[responseArr.length - 1];
                if (responseText.length() > 7) {
                    responseText = responseText.substring(4, responseText.length() - 7);
                }
            }

            long end = System.currentTimeMillis();
            System.out.println("Total response time: " + (end - start) + " ms");
        }
        catch (RestClientException rEx) {
            rEx.printStackTrace();
        }
        return responseText;
    }

    public static ConverseRequest buildConverseRequest(String utterance) {
        ConverseRequest request = new ConverseRequest();
        request.setSession("projects/wmt-c827af4788f644cbb7b76102f/agent/sessions/SD50de201-93420444f2fa501f812df3f2b4323567-b0o7e06");
        ConverseRequest.QueryResult queryResult = new ConverseRequest.QueryResult();
        queryResult.setQueryText(utterance);
        request.setQueryResult(queryResult);
        return request;
    }
    
    private static String encode(String username, String password) {
    	String originalInput = username+":"+password;
    	
    	
         Base64.Encoder enc= Base64.getEncoder();

    	
		try {
			 byte[] strenc =enc.encode(originalInput.getBytes("UTF-8"));
			
			return "Basic "+new String(strenc,"UTF-8");
		} catch (UnsupportedEncodingException e) {
			
			e.printStackTrace();
			return "";
		}
    	
    	
    	
    }
     

    public static DefaultClientConfig addDefaultConfig() {
        DefaultClientConfig restConfig = new DefaultClientConfig();
        Map<String, String> defaultHeaders = new HashMap<>();

        defaultHeaders.put("Content-Type", "application/json;charset=UTF-8");
        defaultHeaders.put("Google-Actions-API-Version", " v2");
        String user = new String(Base64.getDecoder().decode(LoadProperties.loadProperties().getProperty("USER")));
        String pwd = new String(Base64.getDecoder().decode(LoadProperties.loadProperties().getProperty("PWD")));
        defaultHeaders.put("Authorization",encode(user,  pwd));

        restConfig.addDefaultHeaders(defaultHeaders);
        return restConfig;
    }
}
