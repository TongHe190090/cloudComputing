package com.cisco.wccai.grpc.beans;

import io.strati.libs.commons.lang3.builder.ToStringBuilder;
import io.strati.libs.jackson.annotation.JsonIgnoreProperties;
import io.strati.libs.jackson.annotation.JsonInclude;
import io.strati.libs.jackson.annotation.JsonProperty;
import io.strati.libs.jackson.annotation.JsonPropertyOrder;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
		"channelId",
		"conversationId",
		"verticalId",
		"surfaceCapability",
		"message",
		"session",
		"queryResult"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class ConverseRequest {

	@JsonProperty("channelId")
	private String channelId;
	@JsonProperty("conversationId")
	private String conversationId;
	@JsonProperty("verticalId")
	private String verticalId;
	@JsonProperty("surfaceCapability")
	private String surfaceCapability;
	@JsonProperty("message")
	private Message message;
	@JsonProperty("session")
	private String session = "projects/wmt-c827af4788f644cbb7b76102f/agent/sessions/SD50de201-93420444f2fa501f812df3f2b4323567-b0o7e06";
	@JsonProperty("queryResult")
	private QueryResult queryResult;

	@JsonProperty("channelId")
	public String getChannelId() {
		return channelId;
	}

	@JsonProperty("channelId")
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	@JsonProperty("conversationId")
	public String getConversationId() {
		return conversationId;
	}

	@JsonProperty("conversationId")
	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}

	@JsonProperty("verticalId")
	public String getVerticalId() {
		return verticalId;
	}

	@JsonProperty("verticalId")
	public void setVerticalId(String verticalId) {
		this.verticalId = verticalId;
	}

	@JsonProperty("surfaceCapability")
	public String getSurfaceCapability() {
		return surfaceCapability;
	}

	@JsonProperty("surfaceCapability")
	public void setSurfaceCapability(String surfaceCapability) {
		this.surfaceCapability = surfaceCapability;
	}

	@JsonProperty("message")
	public Message getMessage() {
		return message;
	}

	@JsonProperty("message")
	public void setMessage(Message message) {
		this.message = message;
	}

	public QueryResult getQueryResult() {
		return queryResult;
	}

	public void setQueryResult(QueryResult queryResult) {
		this.queryResult = queryResult;
	}

	@Override
	public String toString() {
		return "ConverseRequest{" +
				"channelId='" + channelId + '\'' +
				", conversationId='" + conversationId + '\'' +
				", verticalId='" + verticalId + '\'' +
				", surfaceCapability='" + surfaceCapability + '\'' +
				", message=" + message +
				", session='" + session + '\'' +
				", queryResult=" + queryResult +
				'}';
	}

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonPropertyOrder({
			"type",
			"query"
	})
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class Message {
		@JsonProperty("type")
		private String type;

		@JsonProperty("query")
		private String query;

		@JsonProperty("type")
		public String getType() {
			return type;
		}
		@JsonProperty("type")
		public void setType(String type) {
			this.type = type;
		}

		@JsonProperty("query")
		public String getQuery() {
			return query;
		}
		@JsonProperty("query")
		public void setQuery(String query) {
			this.query = query;
		}
	}

	@JsonProperty("session")
	public String getSession() {
		return session;
	}

	@JsonProperty("session")
	public void setSession(String session) {
		this.session = session;
	}

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonPropertyOrder({
			"queryText"
	})
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class QueryResult {
		@JsonProperty("queryText")
		private String queryText;

		@JsonProperty("queryText")
		public String getQueryText() {
			return queryText;
		}
		@JsonProperty("queryText")
		public void setQueryText(String queryText) {
			this.queryText = queryText;
		}

		@Override
		public String toString() {
			return "QueryResult{" +
					"queryText='" + queryText + '\'' +
					'}';
		}
	}
}

