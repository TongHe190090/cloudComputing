package com.cisco.wccai.grpc.server;

import java.io.*;
import java.nio.ByteBuffer;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cisco.wccai.grpc.server.VAResponse.Item;
import com.cisco.wccai.grpc.service.BlockStorageServiceImpl;
import com.google.api.gax.rpc.ClientStream;
import com.google.api.gax.rpc.ResponseObserver;
import com.google.api.gax.rpc.StreamController;
import com.google.cloud.speech.v1.RecognitionConfig;
import com.google.cloud.speech.v1.SpeechClient;
import com.google.cloud.speech.v1.SpeechRecognitionAlternative;
import com.google.cloud.speech.v1.StreamingRecognitionConfig;
import com.google.cloud.speech.v1.StreamingRecognitionResult;
import com.google.cloud.speech.v1.StreamingRecognizeRequest;
import com.google.cloud.speech.v1.StreamingRecognizeResponse;

import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import java.lang.Runnable;

public class AsyncTaskExecutionWorker implements Runnable{
	private static final Logger LOGGER = LoggerFactory.getLogger(AsyncTaskExecutionWorker.class);
	private  ArrayBlockingQueue<Item> queue;
	private ArrayBlockingQueue<String> replyQueue;
	private String conversationId;
	private volatile boolean finished;
	
	public void setFinished() {
		this.finished = true;
	}
	
	AsyncTaskExecutionWorker( ArrayBlockingQueue<Item> queue,ArrayBlockingQueue<String> replyQueue,String conversationId ){
		this.queue = queue;
		this.replyQueue = replyQueue;
		this.conversationId = conversationId;
	}
	@Override
	public void run() {
		try {
		streamingRecognize();
		}catch(Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		
	}
	
	
	public  void streamingRecognize() throws Exception {

		  ResponseObserver<StreamingRecognizeResponse> responseObserver = null;
		  
		  try (SpeechClient client = SpeechClient.create()) {

		    responseObserver =
		        new ResponseObserver<StreamingRecognizeResponse>() {

		          public void onStart(StreamController controller) {}

		          public void onResponse(StreamingRecognizeResponse response) {
		        	  LOGGER.info("getSpeechEventType {}", response.getSpeechEventType());
		        			        	
		        	 if(response.getSpeechEventType().equals(StreamingRecognizeResponse.SpeechEventType.END_OF_SINGLE_UTTERANCE)){
		        		 setFinished();
		        		 LOGGER.info("find END_OF_SINGLE_UTTERANCE");
		        		 ConversationStateManager.removeWorker(AsyncTaskExecutionWorker.this.conversationId);

		        	 }else {
		        		 LOGGER.info("have not found END_OF_SINGLE_UTTERANCE");
		        	 }
		        	
		        	  if(response.getResultsList().size() ==0) return;
		        	  StreamingRecognitionResult result = response.getResultsList().get(0);
		        	  LOGGER.info("test onComplete {} " , response);
		              SpeechRecognitionAlternative alternative = result.getAlternativesList().get(0);
		              LOGGER.info("Transcript : {}", alternative.getTranscript());
		              try {
						replyQueue.put(alternative.getTranscript());
					} catch (InterruptedException e) {
						
						LOGGER.error(e.getMessage(), e);
					}
		          }

		          public void onComplete() {
		        	  LOGGER.info("test onComplete");
		          }

		          public void onError(Throwable t) {
		        	  LOGGER.error("onError {}", t);
		          }
		        };

		    ClientStream<StreamingRecognizeRequest> clientStream =
		        client.streamingRecognizeCallable().splitCall(responseObserver);

		    RecognitionConfig recognitionConfig =
		        RecognitionConfig.newBuilder()
		            .setEncoding(RecognitionConfig.AudioEncoding.MULAW)
		            .setLanguageCode("en-US")
		            .setModel("phone_call")
		            .setUseEnhanced(true)
		            .setSampleRateHertz(8000)
		            .build();
		    StreamingRecognitionConfig streamingRecognitionConfig =
		        StreamingRecognitionConfig.newBuilder().setConfig(recognitionConfig).setSingleUtterance(true).setInterimResults(false).build();

		    StreamingRecognizeRequest request =
		        StreamingRecognizeRequest.newBuilder()
		            .setStreamingConfig(streamingRecognitionConfig)
		            .build(); // The first request in a streaming call has to be a config

		    clientStream.send(request);

		    while (!finished) {
		    Item item = queue.poll(2, TimeUnit.SECONDS);
		    if(item == null) {
		    	LOGGER.info("an interruption in sending audio file");
		    	ConversationStateManager.removeWorker(AsyncTaskExecutionWorker.this.conversationId);
		    	break;
		    }
		    LOGGER.info("take item {}", item.byteString);
		    if(item.byteString == null) break;
		   
		      request =
		          StreamingRecognizeRequest.newBuilder()
		              .setAudioContent(item.byteString)
		              .build();
		      LOGGER.info("submit to  google api {}", item.byteString);
		      clientStream.send(request);
		      try {
		      saveIntoFile(item.byteString.toByteArray(), this.conversationId );
		      }catch (Exception e) {
		    	  LOGGER.info(e.getMessage(), e);
		      }
		    }
		    clientStream.closeSend();
		    Thread.sleep(5000);
		  } catch (Exception e) {
			  LOGGER.info(e.getMessage(), e);
		  }
		  responseObserver.onComplete();
		}
	
	private int seq;
	private void saveIntoFile(byte[] byteArr, String conversationID) {

		InputStream b_in = null;
		AudioInputStream stream = null;
		FileInputStream fis = null;
		try{
			File file = new File("file.wav");
			if (!file.exists()) {
				file.createNewFile();
			}

			fis = new FileInputStream(file.getAbsolutePath());
			byte[] arr = fis.readAllBytes();

			ByteBuffer byteBuffer = ByteBuffer.allocate(arr.length + byteArr.length)
					.put(arr)
					.put(byteArr);

			b_in = new ByteArrayInputStream(byteBuffer.array());

			AudioFormat format = new AudioFormat(AudioFormat.Encoding.ULAW, 8000f, 8, 1, 2, 8000f, false);
			stream = new AudioInputStream(b_in, format,
					byteBuffer.array().length);

			LOGGER.info(conversationID+ " audio.wav" + " file size {}", arr.length);

			AudioSystem.write(stream, AudioFileFormat.Type.WAVE, file);

			BlockStorageServiceImpl.INSTANCE.write("spch-2-text", file.getAbsolutePath(),
					conversationID + "/audioFile"+seq+".wav");
			seq+=1;
	} catch (Exception e) {
		LOGGER.error(e.getMessage(), e);
	} finally {
		try {
			b_in.close();
			stream.close();
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
		}

		}
	}

}
