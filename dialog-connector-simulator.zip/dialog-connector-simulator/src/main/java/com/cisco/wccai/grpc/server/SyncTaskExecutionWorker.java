package com.cisco.wccai.grpc.server;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cisco.wccai.grpc.server.VAResponse.Item;
import com.google.api.gax.longrunning.OperationFuture;
import com.google.cloud.speech.v1.LongRunningRecognizeMetadata;
import com.google.cloud.speech.v1.LongRunningRecognizeResponse;
import com.google.cloud.speech.v1.RecognitionAudio;
import com.google.cloud.speech.v1.RecognitionConfig;
import com.google.cloud.speech.v1.SpeechClient;
import com.google.cloud.speech.v1.SpeechRecognitionResult;
import com.google.cloud.speech.v1.RecognitionConfig.AudioEncoding;
import com.google.protobuf.ByteString;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.Runnable;

public class SyncTaskExecutionWorker implements Runnable {
	private static final Logger LOGGER = LoggerFactory.getLogger(SyncTaskExecutionWorker.class);
	private ArrayBlockingQueue<Item> queue;
	private ArrayBlockingQueue<String> replyQueue;

	SyncTaskExecutionWorker(ArrayBlockingQueue<Item> queue, ArrayBlockingQueue<String> replyQueue) {
		this.queue = queue;
		this.replyQueue = replyQueue;
	}

	@Override
	public void run() {
		try {

			while (true) {
				boolean shouldStop = false;
				ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
				for (int i = 0; i < 20; i += 1) {

					Item item = queue.take();
					LOGGER.info("take item {}", item.byteString);
					outputStream.write(item.byteString.toByteArray());
					if (item.byteString == null) {
						shouldStop = true;
						break;
					}
						

				}
				replyQueue.put(speechRecognize(outputStream.toByteArray()));
				outputStream.close();
				if(shouldStop) break;

			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}

	}

	public String speechRecognize(byte[] input) throws InterruptedException, ExecutionException {

		try (SpeechClient speech = SpeechClient.create()) {

			ByteString audioBytes = ByteString.copyFrom(input);

			RecognitionConfig config = RecognitionConfig.newBuilder().setEncoding(AudioEncoding.MULAW)
					.setLanguageCode("en-US").setSampleRateHertz(8000).build();
			RecognitionAudio audio = RecognitionAudio.newBuilder().setContent(audioBytes).build();

			OperationFuture<LongRunningRecognizeResponse, LongRunningRecognizeMetadata> response = speech
					.longRunningRecognizeAsync(config, audio);
			LongRunningRecognizeResponse longRunningRecognizeResponse = response.get();
			if (!longRunningRecognizeResponse.getResultsList().isEmpty()) {
				SpeechRecognitionResult subResult = longRunningRecognizeResponse.getResultsList().get(0);
				if (!subResult.getAlternativesList().isEmpty()) {
					return subResult.getAlternativesList().get(0).getTranscript();
				}
			}

		} catch (IOException e) {
			LOGGER.info(e.getMessage(), e);
			return " ";
		}
		return " ";

	}

}
