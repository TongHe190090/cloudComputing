package com.cisco.wccai.grpc.server;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cisco.wcc.ccai.v1.CcaiApi;
import com.cisco.wcc.ccai.v1.CcaiApi.StreamingAnalyzeContentResponse;
import com.cisco.wcc.ccai.v1.Virtualagent;
import com.cisco.wcc.ccai.v1.Virtualagent.Dtmf;
import com.cisco.wccai.grpc.converter.TextToAudioConverter;
import com.cisco.wccai.grpc.integ.ConverseConnector;
import com.cisco.wccai.grpc.server.VAResponse.Item;
import com.google.protobuf.ByteString;

import io.grpc.stub.StreamObserver;

public class ConversationStateManager {
	private static final Logger LOGGER = LoggerFactory.getLogger(ConversationStateManager.class);
	private static ExecutorService threadPool = Executors.newCachedThreadPool();
	private static ConcurrentHashMap<String, ConversationState> queueForConversation = new ConcurrentHashMap<>();
	private static ConcurrentHashMap<String, ConversationDTMFState> dtmfQueueForConversation = new ConcurrentHashMap<>();
	private static ConcurrentHashMap<String, AsyncTaskExecutionWorker> workers = new ConcurrentHashMap<>();
	private static ConcurrentHashMap<String, AsyncDTMFTaskExecutionWorker> dtmfWorkers = new ConcurrentHashMap<>();
	private static final int TASK_QUEUE_SIZE = 1000;
	private static final int REPLY_QUEUE_SIZE = 1000;

	private ConversationStateManager() {
	}

	public static class ConversationState {
		public ConversationState(ArrayBlockingQueue<Item> tasks, ArrayBlockingQueue<String> replyQueue,
				VAResponse vaResponse) {
			this.tasks = tasks;
			this.replyQueue = replyQueue;
			this.vaResponse = vaResponse;
		
		}
		int waitingtimes =0;
		ArrayBlockingQueue<Item> tasks;
		ArrayBlockingQueue<String> replyQueue;
		VAResponse vaResponse;
	}
	
	public static class ConversationDTMFState{
		public ConversationDTMFState(ArrayBlockingQueue<Virtualagent.Dtmf> dtmfSymbols, ArrayBlockingQueue<String> replyQueue,
				VAResponse vaResponse) {
			this.dtmfSymbols = dtmfSymbols;
			this.replyQueue = replyQueue;
			this.vaResponse = vaResponse;
			
			
		}
		ArrayBlockingQueue<Virtualagent.Dtmf> dtmfSymbols;
		ArrayBlockingQueue<String> replyQueue;
		VAResponse vaResponse;
		
		
		
	}
	
	public static void removeWorker(String conversationId) {
		workers.remove(conversationId);
	}

	public static ConversationState getConversationState(String conversationId, ByteString audio) {
		LOGGER.info("getting conversation state for conversation id: {}", conversationId);
	
		ConversationState conversationState = queueForConversation.get(conversationId);
		if (conversationState == null) {
			ArrayBlockingQueue<String> replyQueue = new ArrayBlockingQueue<String>(REPLY_QUEUE_SIZE);
			ConversationState newConversationState = new ConversationState(
					new ArrayBlockingQueue<Item>(TASK_QUEUE_SIZE), replyQueue,
					new VAResponse());
		
			conversationState = queueForConversation.putIfAbsent(conversationId, newConversationState);
			if (conversationState == null)
				conversationState = newConversationState;
		}
		
		if(audio != null) {
			LOGGER.info("get audio byte {}", audio);
			try {
				conversationState.tasks.put(new Item(audio));
			}catch(Exception e) {
				LOGGER.info(e.getMessage(), e);
			}
			
		}
		
		AsyncTaskExecutionWorker worker = workers.get(conversationId);
		if (audio != null && worker == null) {
			AsyncTaskExecutionWorker newWorker = new AsyncTaskExecutionWorker(conversationState.tasks, conversationState.replyQueue,conversationId);
			worker = workers.putIfAbsent(conversationId, newWorker);
			if (worker == null)
				worker = newWorker;
			threadPool.submit(worker);
			LOGGER.info("work submitted {} ", worker);
		}
		return conversationState;
	}
	
	public static void releaseAllResource(String conversationId) {
		workers.remove(conversationId);
		queueForConversation.remove(conversationId);
		LOGGER.info("release resources for {}", conversationId);
		
	}

	
    private static int replySeq = 0;
	public static boolean processReply(String conversationId,StreamObserver<CcaiApi.StreamingAnalyzeContentResponse> responseObserver) {
		ConversationState  taskAndReplyQueue = ConversationStateManager.getConversationState(conversationId, null);
		ArrayBlockingQueue<String> replyQuee = taskAndReplyQueue.replyQueue;
		if(replyQuee.isEmpty()) return false;
		String reply = replyQuee.poll();
		LOGGER.info("utterance {}", reply);
		LOGGER.info("get response from google speech-to-text api , the reply is  {}", reply);
		String converseResponse = ConverseConnector.sendRequestToConverse(reply);
		if(converseResponse.equals(ConverseConnector.TRANSFER_AGENT_TEXT)) {
			    LOGGER.info("send transfer transfer event");
			 	responseObserver.onNext(PrepareResponse.createResponseForExitEvent());
			 	LOGGER.info("finish sending transfer transfer event");
			 	replyQuee.clear();
			 	return true;
			 	
			
		}
		if (reply != null) {
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			try {
				if (converseResponse != null) {

					LOGGER.info("converse short text  {}", converseResponse);
					TextToAudioConverter.synthesizeText(converseResponse, outputStream);
					byte[] byteArray = outputStream.toByteArray();
					LOGGER.info("send response audio {}", byteArray.length);
					responseObserver.onNext(
							PrepareResponse.prepareFinalVAResponse(ByteString.copyFrom(byteArray))
									.getFinalVAResponse());
					FileOutputStream fis = new FileOutputStream(conversationId+"converse+"+replySeq+".wav");
					replySeq+=1;
					fis.write(byteArray);
					fis.close();

				}
				
			} catch (Exception e) {
				LOGGER.error(e.getMessage(), e);
			} finally {
				try {
					outputStream.close();
				} catch (IOException e) {
					LOGGER.error(e.getMessage(), e);
				}
			}
		}
		return false;
	}

	public static void sendWelcome(String conversationId,StreamObserver<CcaiApi.StreamingAnalyzeContentResponse> responseObserver) {
		String converseResponse = ConverseConnector.sendRequestToConverse("hello");
		//String converseResponse = "Thank you for considering Walmart as your next step in your career journey! How can I help you today? For example, you can say something such as \\\"I would like to check my background status\\\" or \\\"I want to reset my password\\\".";
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		try {
			if (converseResponse != null) {
				LOGGER.info("converse short text  {}", converseResponse);
				TextToAudioConverter.synthesizeText(converseResponse, outputStream);
				byte[] byteArray = outputStream.toByteArray();
				LOGGER.info("send response audio {}", byteArray.length);
				//responseObserver.onNext(Context.getResponse(State.CALL_START).getCallStartResponse());
				responseObserver.onNext(
						PrepareResponse.prepareCallStartResponse(ByteString.copyFrom(byteArray))
								.getCallStartResponse());
				FileOutputStream fis = new FileOutputStream(conversationId+"converse+"+replySeq+".wav");
				replySeq+=1;
				fis.write(byteArray);
				fis.close();
			}
		}
		catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				outputStream.close();
			}
			catch (IOException e) {
				LOGGER.error(e.getMessage(), e);
			}
		}
	}

	public static ConversationDTMFState getConversationStateForDTMF(String conversationId, Dtmf dtmf) {
		
		LOGGER.info("getting conversation DTMF state for conversation id: {}", conversationId);
		
		ConversationDTMFState conversationState = dtmfQueueForConversation.get(conversationId);
		if (conversationState == null) {
			ArrayBlockingQueue<String> replyQueue = new ArrayBlockingQueue<String>(REPLY_QUEUE_SIZE);
			ConversationDTMFState newConversationState = new ConversationDTMFState(
					new ArrayBlockingQueue<Virtualagent.Dtmf>(TASK_QUEUE_SIZE), replyQueue,
					new VAResponse());
		
			conversationState = dtmfQueueForConversation.putIfAbsent(conversationId, newConversationState);
			if (conversationState == null)
				conversationState = newConversationState;
		}
		
		if(dtmf != null) {
			LOGGER.info("get dtmf info {}", dtmf);
			try {
				conversationState.dtmfSymbols.put(dtmf);
			}catch(Exception e) {
				LOGGER.info(e.getMessage(), e);
			}
			
		}
		
		AsyncDTMFTaskExecutionWorker worker = dtmfWorkers.get(conversationId);
		if (dtmf != null && worker == null) {
			AsyncDTMFTaskExecutionWorker newWorker = new AsyncDTMFTaskExecutionWorker(conversationState.dtmfSymbols, conversationState.replyQueue,conversationId);
			worker = dtmfWorkers.putIfAbsent(conversationId, newWorker);
			if (worker == null)
				worker = newWorker;
			threadPool.submit(worker);
			LOGGER.info("work submitted {} ", worker);
		}
		return conversationState;
	
	}

	public static void processReplyForDTMF(String conversationId,
			StreamObserver<StreamingAnalyzeContentResponse> responseObserver, boolean clearQueue) {
		ConversationDTMFState  taskAndReplyQueue = ConversationStateManager.getConversationStateForDTMF(conversationId, null);
		ArrayBlockingQueue<String> replyQuee = taskAndReplyQueue.replyQueue;
		if(clearQueue) {
			replyQuee.clear();
		}else if(!replyQuee.isEmpty()) {
			String reply = replyQuee.poll();
			LOGGER.info("dtmf whole message {}", reply);
			String converseResponse = ConverseConnector.sendRequestToConverse(reply);
			if (reply != null) {
				ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
				try {
					if (converseResponse != null) {

						LOGGER.info("converse short text  {}", converseResponse);
						TextToAudioConverter.synthesizeText(converseResponse, outputStream);
						byte[] byteArray = outputStream.toByteArray();
						LOGGER.info("send response audio {}", byteArray.length);
						responseObserver.onNext(
								PrepareResponse.prepareFinalVAResponse(ByteString.copyFrom(byteArray))
										.getFinalVAResponse());
						FileOutputStream fis = new FileOutputStream(conversationId+"converse+"+replySeq+".wav");
						replySeq+=1;
						fis.write(byteArray);
						fis.close();

					}
					
				} catch (Exception e) {
					LOGGER.error(e.getMessage(), e);
				} finally {
					try {
						outputStream.close();
					} catch (IOException e) {
						LOGGER.error(e.getMessage(), e);
					}
				}
			}
			
		}
		
		
	}

}
