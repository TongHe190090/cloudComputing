package com.cisco.wccai.grpc.converter;

import com.google.api.gax.longrunning.OperationFuture;
import com.google.cloud.speech.v1.*;
import com.google.protobuf.ByteString;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AudioToTextConverter {
	private static final Logger LOGGER = LoggerFactory.getLogger(AudioToTextConverter.class);
	public static void main(String [] args) {
		System.out.println("rte "+ new AudioToTextConverter().speechRecognizeFile("/Users/t0h0efk/project/project2/ccai-cisco/dialog-connector-simulator/src/main/resources/audio/flightbook.wav"));
		
	}
	

    public static String speechRecognize(byte[] input) {

        StringBuilder result = new StringBuilder();
        try (SpeechClient speech = SpeechClient.create()) {

            ByteString audioBytes = ByteString.copyFrom(input);

            RecognitionConfig config = RecognitionConfig.newBuilder().setEncoding(RecognitionConfig.AudioEncoding.MULAW)
                    .setLanguageCode("en-US").setSampleRateHertz(8000).build();
            RecognitionAudio audio = RecognitionAudio.newBuilder().setContent(audioBytes).build();

            // Use blocking call to get audio transcript
            RecognizeResponse response = speech.recognize(config, audio);
            List<SpeechRecognitionResult> results = response.getResultsList();

            for (SpeechRecognitionResult subResult : results) {
                SpeechRecognitionAlternative alternative = subResult.getAlternativesList().get(0);
                result.append(alternative.getTranscript());
                result.append(" ");

            }
            return result.toString();

        } catch (IOException e) {
        	LOGGER.error(e.getMessage(), e);
        }
		return "";

    }

    public static String speechRecognizeFile(String fileName) {
        Path path = Paths.get(fileName);
        byte[] data;
        try {
            data = Files.readAllBytes(path);

            return speechRecognize(data);
        } catch (IOException e) {
        	LOGGER.error(e.getMessage(), e);
        }
        return "";

    }

    public static void asyncRecognizeFile(String fileName) throws Exception {
        // Instantiates a client with GOOGLE_APPLICATION_CREDENTIALS
        try (SpeechClient speech = SpeechClient.create()) {

            Path path = Paths.get(fileName);
            byte[] data = Files.readAllBytes(path);
            ByteString audioBytes = ByteString.copyFrom(data);

            // Configure request with local raw PCM audio
            RecognitionConfig config =
                    RecognitionConfig.newBuilder()
                            .setEncoding(RecognitionConfig.AudioEncoding.MULAW)
                            .setLanguageCode("en-US")
                            .setSampleRateHertz(8000)
                            .build();
            RecognitionAudio audio = RecognitionAudio.newBuilder().setContent(audioBytes).build();

            // Use non-blocking call for getting file transcription
            OperationFuture<LongRunningRecognizeResponse, LongRunningRecognizeMetadata> response =
                    speech.longRunningRecognizeAsync(config, audio);

            while (!response.isDone()) {
                System.out.println("Waiting for response...");
                Thread.sleep(10000);
            }

            List<SpeechRecognitionResult> results = response.get().getResultsList();

            for (SpeechRecognitionResult result : results) {
                // There can be several alternative transcripts for a given chunk of speech. Just use the
                // first (most likely) one here.
                SpeechRecognitionAlternative alternative = result.getAlternativesList().get(0);
                System.out.printf("Transcription: %s%n", alternative.getTranscript());
            }
        }
    }
}
