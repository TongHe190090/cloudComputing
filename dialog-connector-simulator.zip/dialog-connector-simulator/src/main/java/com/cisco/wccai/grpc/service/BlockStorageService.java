package com.cisco.wccai.grpc.service;

public interface BlockStorageService {
	public void write(String bucketName, String filePath, String objectName) throws Exception;
	
	public void read(String bucketName, String objectName, String outputFileFullPath) throws Exception;

}