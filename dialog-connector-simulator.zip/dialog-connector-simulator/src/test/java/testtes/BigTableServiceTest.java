package testtes;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.cisco.wccai.grpc.service.BigTableOperationService;
import com.cisco.wccai.grpc.service.BigTableService;

public class BigTableServiceTest {
	public static void main(String [] args) {
		try {
			BigTableOperationService service = new BigTableService("wmt-et-converse-dev", "testInstanceId", "tableId");
			service.createTable("mycolumnFamily");
			List<String[]> values = new ArrayList<>();
			values.add(new String[] {"myValue"});
			service.writeToTable("mycolumnFamily", "myKey", values);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
